Run on machine learning class server.
2 files: knn.py, decisionTree.py

commands to run:
1. python knn.py
2. python decisionTree.py

Both program should run since all the libraries are installed.
If the program does not run, please source the virtualenv:
bash shell: source /scratch/cs434spring2018/env_2.7/bin/activate
C shell: source /scratch/cs434spring2018/env_2.7/bin/activate.csh
